---
name: microdemo
description: Create a microdemo — a tightly-scoped, throwaway, single-file interactive HTML demo that exposes implicit assumptions about ambiguous product requirements. Use this skill whenever the user asks to "build a microdemo", "make a spike", "create a one-page interactive demo for X", or wants to align with product/stakeholders on something subjective (search relevance, ranking, recommendations, scoring, copy variants, design tokens, threshold tuning). Trigger even if the user just says "microdemo" without further context, or describes the underlying problem (e.g., "I need to talk to product about how we rank X") in a way that would benefit from a throwaway interactive artifact instead of a written doc. Use this skill in lieu of writing a design doc when the requirements involve subjective judgment that's easier to feel than describe.
---

# Microdemo

A microdemo is a throwaway, single-page interactive HTML artifact built to *replace* a design doc when the requirements are subjective. The goal is to make implicit assumptions concrete so a stakeholder conversation gets to "should this be ranked higher?" instead of stalling on "what does relevance mean?"

This is a tool for talking, not shipping. Don't sink time into UI polish, but the simulated logic must be correct and the surface must read on a screenshare.

## References

Based on the microdemo concept by Nadav Ami. Source post: <https://nadav.ca/posts/microdemos-just-show-them/>

Two finished examples are linked from the post. Fetch them only when you need a concrete output reference — when the user's request blends flavors, or when you're uncertain how a section should look in practice. Skip otherwise; this skill encodes the principles already.

- Spike doc flavor (rec-ranking): <https://nadav.ca/posts/microdemos-just-show-them/microdemos/rec-ranking.html>
- Lab flavor (color-lab): <https://nadav.ca/posts/microdemos-just-show-them/microdemos/color-lab.html>

## Push back when there's nothing to interact with

If the request has no meaningful interactive surface — sliders to tune, toggles to flip, scenarios to compare, a preview to react to — say so. A microdemo without interactivity is a static doc with extra steps; suggest a doc, sketch, or screenshot grid instead. Offer a microdemo for an adjacent question if one fits.

Push-back triggers:
- Purely descriptive (strategy, vision, "why we should X")
- Documentation by another name (API shape, data model with no tunable behavior)
- "Interaction" would be cosmetic (toggling pre-rendered states with no underlying logic)

## Asking

Bias toward producing, but a v1 generated from too little context is still useless. Ask one round when the prompt doesn't give you enough to produce something the user could meaningfully react to — then go.

Ask when missing:
- The underlying problem, if you only have a feature name
- The mechanic, if the problem implies multiple plausible approaches (BM25 vs vector vs weighted sum, hard threshold vs soft decay)
- Whether to read attached files or a pointed-at repo
- Constraints on the eventual implementation, if not implied (see Feasibility)

Don't ask about: polish, color, font, edge cases, "should I include X" (include it; put unknowns under Open Questions). Don't go fishing in the user's filesystem; only read what they've attached or pointed at.

Cap at 2 questions in `ask_user_input_v0`, or one terse plain-text round. State assumptions for everything else inline in Scope or Open Questions.

## Required components

Every microdemo has these, even if labels differ by flavor:

1. **Problem statement** — one paragraph. What's broken or ambiguous, in concrete language a non-engineer can read.
2. **Scope callout** — explicitly what's in and out. Out-of-scope items are how you avoid being asked to "just add" things mid-meeting.
3. **Interactive surface** — the thing they came for. Sliders, toggles, scenario presets, side-by-side comparisons, live previews. The user must be able to *do* something that changes the output. If you generate synthetic data, render it visibly in the UI (in the result rows, an inspectable table, a hover affordance) — not just buried in a JS array.
4. **Proposed approach** — a short prose explanation of the mechanic, with a worked example pulled from the live state when it helps (e.g., "this row scores 2.3 = distance(0.8)*1 + rating(0.6)*2.5...").
5. **Open questions** — 3-5 questions the demo deliberately doesn't answer. Pull from the user's prompt, attached requirements, and chat context first; add your own only after exhausting what's already been raised.

## Feasibility

The mechanic the demo simulates must be implementable in the user's stack, or the conversation is theater. If you're proposing BM25, vector search, real-time recomputation, or anything infra-heavy, verify the team can actually build it — read the repo and pick a mechanic that maps. If the user signals a stack change is coming ("we're moving to Elasticsearch") or the agent observes one in flight, a forward-looking mechanic is fine; call that out in Scope.

When in doubt, propose a mechanic on the simpler/already-built side and put more sophisticated alternatives in Open Questions.

## Two flavors

Pick based on the problem shape. They're not mutually exclusive — sometimes a hybrid is right.

### Spike doc flavor

Use when the question is "how should this work?" — ranking, scoring, weighting, threshold tuning, recommendation logic, A/B variant comparison. The demo is embedded inside what reads like a one-page design doc.

Shape: header (title + ticket-style subtitle) → problem → scope → controls + side-by-side result columns → proposed approach → open questions.

Hallmarks: synthetic dataset hand-coded as a JS array at the top of the script, named scenario presets that snap controls to common shapes ("Quick lunch nearby", "Date night"), per-row scoring breakdown when the math matters.

**Page structure:**

```
.doc (max-width ~1280px, centered, generous bottom padding)
  .doc-header
    .doc-title           — "Spike: <Feature Name>"
    .doc-subtitle        — "<TICKET-NUM> · <subtopic> · <date>"

  .section-label "Problem"
  .prose                 — one paragraph, concrete language
  .callout.info          — Scope: in / out, terse

  .section-label "Interactive Demo"
  .scenario-row          — preset chips, click to snap controls
  .controls-grid (2 col) — slider groups, gate toggles
  .columns (2 col)       — side-by-side result cards
    .col-card            — current/baseline
    .col-card            — proposed/weighted

  .section-label "Proposed Approach"
  .prose                 — explain the mechanic
  .scoring-example       — per-row breakdown of one item, math visible
  .prose                 — call out tradeoffs

  .section-label "Open Questions"
  .questions-table       — single column, 3-5 rows
```

**Section label conventions** (override only with reason):

- **Problem** — what's broken
- **Scope** — when it's its own section vs a callout
- **Interactive Demo** — controls + result area
- **Proposed Approach** — the mechanic explanation
- **Out of Scope** — when there's enough exclusion to deserve its own list (otherwise fold into Scope callout)
- **Open Questions** — always last

**CSS patterns:**

```css
:root {
  --bg: #0f1117; --surface: #1a1d27; --surface2: #22252f;
  --border: #2a2d3a; --text: #e4e4e7; --text-dim: #9ca3af;
  --text-xdim: #6b7280; --accent: #6366f1;
  --green: #22c55e; --yellow: #eab308; --red: #ef4444;
}

body {
  font-family: 'Commit Mono', 'SF Mono', 'Fira Code', 'Consolas', monospace;
  background: var(--bg); color: var(--text);
  font-size: 15px; line-height: 1.6;
}

.doc-title    { font-size: 28px; font-weight: 700; letter-spacing: -0.5px; }
.doc-subtitle { font-size: 13px; color: var(--text-dim); }
.prose        { font-size: 15px; line-height: 1.7; }

.section-label {
  font-size: 11px; text-transform: uppercase;
  letter-spacing: 1.5px; color: var(--text-xdim);
  margin: 48px 0 12px;
}
.section-label:first-of-type { margin-top: 0; }

.callout {
  border-left: 3px solid var(--border);
  padding: 14px 18px; background: var(--surface);
  border-radius: 0 8px 8px 0; font-size: 14px;
  line-height: 1.7; margin-bottom: 20px;
}
.callout.info { border-left-color: var(--accent); }
.callout.warn { border-left-color: var(--yellow); }

.scenario-btn {
  font: inherit; font-size: 13px;
  padding: 8px 14px; background: var(--surface);
  color: var(--text-dim); border: 1px solid var(--border);
  border-radius: 6px; cursor: pointer;
}
.scenario-btn.active {
  background: var(--accent); color: white; border-color: var(--accent);
}

.slider-row {
  display: grid; grid-template-columns: 90px 1fr 50px;
  align-items: center; gap: 14px; margin-bottom: 10px;
  font-size: 14px;
}
.slider-row input[type="range"] { accent-color: var(--accent); height: 6px; }

.col-card {
  background: var(--surface); border: 1px solid var(--border);
  border-radius: 8px; padding: 18px;
}

.questions-table { width: 100%; border-collapse: collapse; font-size: 14px; }
.questions-table td {
  padding: 12px 14px; border-bottom: 1px solid var(--border);
  line-height: 1.5; vertical-align: top;
}
```

**Synthetic data shape** — top-of-script `const`, 8-15 items, values chosen so different settings reorder them visibly:

```js
const ITEMS = [
  { name: 'Sakura House',    rating: 4.6, reviews: 320, distKm: 1.2, lastVisit: null },
  { name: 'Le Petit Bistro', rating: 4.8, reviews: 210, distKm: 8.5, lastVisit: null },
  { name: 'Corner Deli',     rating: 3.2, reviews: 85,  distKm: 0.2, lastVisit: '2026-04-25' },
  // ...
];

const SCENARIOS = [
  { label: 'Balanced',           weights: { distance: 1, rating: 1, reviews: 1, recency: 1 } },
  { label: 'Quick lunch nearby', weights: { distance: 3, rating: 0.5, reviews: 0.5, recency: 0.5 } },
  // ...
];
```

**Scoring pattern** — normalize each signal to 0-1, weighted sum, optional gate:

```js
function scoreWeighted(item, weights) {
  const signals = computeSignals(item);
  return Object.keys(weights).reduce((sum, k) => sum + signals[k] * weights[k], 0);
}
```

Each result column gets the same data, sorted by a different score function. Show signal breakdowns inline so the math is auditable.

### Lab/explorer flavor

Use when the question is "what should this look or feel like?" — design tokens, color palettes, copy tone, content density, component variants. The demo is a workbench: pickers/inputs on one side, live preview of real surfaces on the other.

Shape: split-pane (controls panel ~320px + preview canvas) where the preview uses the *actual* surfaces from the codebase if reachable — real fonts, real layout HTML, real CSS variable names — so changes look like changes to production, not abstract swatches.

Hallmarks: every variable gets a picker, derived metrics rendered live next to the affected element (contrast scores beside text samples, line-length counts beside paragraphs), no synthetic data — the data is the design itself.

**Page structure:**

```
.lab (grid: 320px 1fr, full-height)
  .panel (sticky left, scrollable)
    h1 — "<surface> color lab" / "<surface> tokens"
    .picker-group × N
      label
      input[type=color] / input[type=range] / select
      .picker-meta — current value, derived metric

  .preview (right, scrollable)
    .preview-section × N
      h2 / .surface-label
      <real markup from codebase>
      .annotations — derived metrics rendered inline
```

For lab flavor, labels are surface-specific (`Tokens`, `Typography`, `Surfaces`, `Components`) — no generic doc structure.

**Key patterns:**

- `@font-face` declarations inline at the top of `<style>`, paths relative to where the file lives in the repo. This is how you get *real* fonts into the throwaway.
- Pickers update CSS variables on `:root` directly; the preview just inherits. One-line update handlers.
- For each token, render its current value next to the picker so users can copy it back to their stylesheet.
- Contrast widget: WCAG ratio computed live, score badge (AAA/AA/AA Large/Fail) next to each text-on-background pairing.

```js
const tokens = {
  '--bg': '#1a1a1a',
  '--surface': '#242424',
  '--text': '#cccccc',
  // ...
};

function applyToken(name, value) {
  document.documentElement.style.setProperty(name, value);
  document.querySelector(`[data-meta="${name}"]`).textContent = value;
  refreshDerivedMetrics();
}
```

Hex-to-RGB and luminance for contrast scoring:

```js
function luminance(hex) {
  const rgb = [
    parseInt(hex.slice(1, 3), 16) / 255,
    parseInt(hex.slice(3, 5), 16) / 255,
    parseInt(hex.slice(5, 7), 16) / 255,
  ].map(c => c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4));
  return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2];
}

function contrast(a, b) {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (hi + 0.05) / (lo + 0.05);
}
```

## Output constraints

- **Single self-contained HTML file.** No external CSS/JS, no `fetch`, no CDN dependencies. Inline everything. The point is "open the file, it works, anywhere — even airplane wifi."
- **Synthetic data inline.** 8-15 hand-coded items chosen so the controls *do something visible* — include items that swap order under different settings. Use realistic domain values, not Lorem ipsum. (Lab flavor exempt — its "data" is the surface itself.)
- **No build step.** Vanilla JS, no JSX, no TypeScript, no React. Even if the user's repo is React-based, the spike is plain HTML — the conversation is about logic, not framework choice.
- **Save to `microdemos/<slug>.html`** in the working directory unless the user specifies otherwise. Slug is kebab-case and topic-specific (`rec-ranking`, `color-lab`, not `demo-1`).
- **Length target: 400-1000 lines** of HTML+CSS+JS combined. Under 200 is probably under-scoped; over 1500 is trying to be a product.

## Aesthetic — readable on a screenshare

Optimize for legibility when projected, zoomed, or shared. Throwaway-feeling but usable.

- **Mono body font.** `Commit Mono`, `SF Mono`, `Fira Code`, `Consolas`, `ui-monospace`. Reads as engineering-doc.
- **Dark surface, dim borders, one accent for the active/proposed result.** Reference palette: `--bg: #0f1117`, `--surface: #1a1d27`, `--border: #2a2d3a`, `--accent: #6366f1`, `--text-dim: #9ca3af`. Status colors only when status is meaningful.
- **Sized for projection.** Body 14-15px minimum, titles 28-32px, controls clearly hittable. The originals are tight when shared; push up. Section labels stay small (10-11px uppercase).
- **No motion beyond instant state updates.** No page-load animations, hero treatments, or scroll-triggered reveals.

If the user's repo has a stylesheet or design tokens, read them and use those colors instead — especially for the lab flavor where the demo should look like the product.

### On pulling in `frontend-design`

`frontend-design` (`/mnt/skills/public/frontend-design/SKILL.md`) is biased toward distinctive/maximalist aesthetics — wrong default here. If you consult it, override:

- Distinctive fonts → mono only.
- Bold aesthetic direction → "engineer's spike doc."
- Atmospheric backgrounds, gradients, motion → none.
- Production polish → don't optimize for it. Correctness of the simulated logic and screenshare legibility are the bars.

## Working from a codebase

If the user pointed at a repo, or one is in cwd:

- **Read the schema/types** for the feature first. Synthetic data should match real field names, units, ranges.
- **For the lab flavor, read the actual stylesheet and layout.** Use real CSS variable names. Copy real markup slices.
- **Copy inline; don't import.** The demo must run standalone with the file double-clicked.

If there's no codebase, infer the schema from the problem description and label it inline as inferred so the user can correct it.

## Iteration

After v1, note 2-3 hooks for the next pass — extra signals, different scenario presets, different gate behavior. Increments, not a roadmap.

When the user asks for a change, make it and re-emit the file. Don't refactor.

## Anti-patterns

Don't:
- Build multi-page apps, routing, navigation
- Add a backend beyond `setTimeout`
- Add auth, real APIs, persistence
- Wrap in a build step or framework setup
- Output a Markdown doc instead of HTML — interactivity is the point
- Generate a 50-row synthetic dataset when 12 will do
- Generate scenario presets for every conceivable use — 3-5

## Reference prompt

> *Look at the restaurant model in the codebase and build me a one-page interactive spike doc for our "recommended for you" ranking. Frame it as a problem statement with an interactive demo. Generate synthetic data that matches the schema. Signals: distance, rating, review count, recency. Sliders for each weight so product can tune them. Include open questions and out of scope from the attached requirements doc. The output should be a single HTML file with no external data calls.*

When the user's prompt is sparser, fill in the structural defaults — the five required components, the aesthetic, the constraints — without making them spell it out.
